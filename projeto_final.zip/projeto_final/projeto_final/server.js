const express = require('express');
const mqtt = require('mqtt');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 8000;

// Configurações do cliente MQTT
const mqttClient = mqtt.connect('mqtt://iluminacao:D5ubCjvE0ASDln1u@iluminacao.cloud.shiftr.io'); // Use o broker MQTT que preferir

mqttClient.on('connect', () => {
    console.log('Conectado ao broker MQTT');
});

// Middleware
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Rota para enviar comando de ligar/desligar
app.post('/send-command', (req, res) => {
    const { command } = req.body;
    mqttClient.publish('controle/comando', command, () => {
        console.log(`Comando enviado: ${command}`);
        res.sendStatus(200);
    });
});

// Rota para enviar variável
app.post('/send-variable', (req, res) => {
    const { variable } = req.body;
    mqttClient.publish('controle/variavel', variable, () => {
        console.log(`Variável enviada: ${variable}`);
        res.sendStatus(200);
    });
});

// Serve o arquivo HTML na rota raiz
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});